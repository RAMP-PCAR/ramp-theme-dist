/*! ramp-theme-canada 25-03-2015 19:31:24 : v. 5.2.0-rc2 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Canada.ca Theme 
 **/
define([],function(){"use strict";return{getFindFcn:function(a,b){function c(c){return a(b,c)}return c}}});