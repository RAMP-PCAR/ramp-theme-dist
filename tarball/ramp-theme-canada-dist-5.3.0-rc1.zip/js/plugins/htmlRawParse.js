/*! ramp-theme-canada Plugins 27-04-2015 19:12:18 : v. 5.3.0-rc1 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Canada.ca Theme 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};