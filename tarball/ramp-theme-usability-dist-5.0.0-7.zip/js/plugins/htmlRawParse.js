/*! ramp-theme-usability Plugins 30-01-2015 15:07:14 : v. 5.0.0-7 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Usability Theme 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};