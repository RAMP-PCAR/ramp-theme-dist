/*! ramp-theme-usability Plugins 27-04-2015 19:20:59 : v. 5.3.0-rc1 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Usability Theme 
 **/
RAMP.plugins.featureInfoParser.jsonRawParse=function(a){"use strict";return"<p>{0}</p>".format(a)};