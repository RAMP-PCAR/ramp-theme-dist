/*! ramp-theme-usability Plugins 25-03-2015 19:34:31 : v. 5.2.0-rc2 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Usability Theme 
 **/
RAMP.plugins.featureInfoParser.stringParse=function(a){"use strict";return"<p>{0}</p>".format(a)};