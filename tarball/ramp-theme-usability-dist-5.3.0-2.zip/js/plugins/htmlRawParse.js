/*! ramp-theme-usability Plugins 07-04-2015 12:26:01 : v. 5.3.0-2 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Usability Theme 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};