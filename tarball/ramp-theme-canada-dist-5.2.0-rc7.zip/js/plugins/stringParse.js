/*! ramp-theme-canada Plugins 31-03-2015 16:30:28 : v. 5.2.0-rc7 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Canada.ca Theme 
 **/
RAMP.plugins.featureInfoParser.stringParse=function(a){"use strict";return"<p>{0}</p>".format(a)};