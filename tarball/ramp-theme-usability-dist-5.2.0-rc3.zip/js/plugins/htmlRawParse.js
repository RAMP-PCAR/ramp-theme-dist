/*! ramp-theme-usability Plugins 26-03-2015 18:44:19 : v. 5.2.0-rc3 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Usability Theme 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};