/*! ramp-theme-intranet 30-01-2015 15:27:58 : v. 5.0.0-8 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Intranet Theme 
 **/
define([],function(){"use strict";return{getFindFcn:function(a,b){function c(c){return a(b,c)}return c}}});