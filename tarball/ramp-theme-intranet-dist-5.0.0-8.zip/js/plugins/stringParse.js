/*! ramp-theme-intranet Plugins 30-01-2015 15:28:12 : v. 5.0.0-8 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Intranet Theme 
 **/
RAMP.plugins.featureInfoParser.stringParse=function(a){"use strict";return"<p>{0}</p>".format(a)};