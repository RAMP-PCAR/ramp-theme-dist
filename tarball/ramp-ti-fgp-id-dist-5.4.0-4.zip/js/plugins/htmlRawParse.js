/*! ramp-ti-fgp-id Plugins 08-05-2015 12:13:12 : v. 5.4.0-4 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Intranet Theme 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};