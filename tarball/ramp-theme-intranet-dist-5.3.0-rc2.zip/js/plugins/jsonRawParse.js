/*! ramp-theme-intranet Plugins 28-04-2015 15:32:08 : v. 5.3.0-rc2 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Intranet Theme 
 **/
RAMP.plugins.featureInfoParser.jsonRawParse=function(a){"use strict";return"<p>{0}</p>".format(a)};