/*! ramp-theme-intranet Plugins 07-05-2015 18:28:53 : v. 5.4.0-4 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Intranet Theme 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};