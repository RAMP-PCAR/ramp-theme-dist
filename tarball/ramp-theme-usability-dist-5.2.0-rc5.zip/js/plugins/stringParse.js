/*! ramp-theme-usability Plugins 27-03-2015 18:33:38 : v. 5.2.0-rc5 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Usability Theme 
 **/
RAMP.plugins.featureInfoParser.stringParse=function(a){"use strict";return"<p>{0}</p>".format(a)};