/*! ramp-theme-usability Plugins 23-02-2015 04:39:42 : v. 5.1.0-1 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Usability Theme 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};