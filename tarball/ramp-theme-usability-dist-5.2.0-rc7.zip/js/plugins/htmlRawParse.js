/*! ramp-theme-usability Plugins 31-03-2015 16:35:39 : v. 5.2.0-rc7 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Usability Theme 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};