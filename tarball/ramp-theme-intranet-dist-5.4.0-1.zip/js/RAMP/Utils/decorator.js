/*! ramp-theme-intranet 30-04-2015 18:03:24 : v. 5.4.0-1 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Intranet Theme 
 **/
define([],function(){"use strict";return{getFindFcn:function(a,b){function c(c){return a(b,c)}return c}}});