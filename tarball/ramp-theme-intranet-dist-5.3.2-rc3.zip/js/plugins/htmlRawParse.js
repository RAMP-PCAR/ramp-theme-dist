/*! ramp-theme-intranet Plugins 21-05-2015 14:08:42 : v. 5.3.2-rc3 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Intranet Theme 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};