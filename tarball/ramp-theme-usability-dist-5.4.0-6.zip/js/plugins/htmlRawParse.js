/*! ramp-theme-usability Plugins 08-05-2015 15:07:28 : v. 5.4.0-6 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Usability Theme 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};