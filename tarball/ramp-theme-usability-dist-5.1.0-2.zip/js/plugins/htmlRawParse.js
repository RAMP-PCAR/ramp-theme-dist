/*! ramp-theme-usability Plugins 02-03-2015 17:41:29 : v. 5.1.0-2 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Usability Theme 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};