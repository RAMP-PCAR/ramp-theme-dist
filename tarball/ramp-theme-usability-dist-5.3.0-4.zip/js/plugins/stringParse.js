/*! ramp-theme-usability Plugins 24-04-2015 14:45:13 : v. 5.3.0-4 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Usability Theme 
 **/
RAMP.plugins.featureInfoParser.stringParse=function(a){"use strict";return"<p>{0}</p>".format(a)};